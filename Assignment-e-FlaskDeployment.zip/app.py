# Filename: app.py
# Purpose: The main Flask app that is compiled and executed.


from flask import Flask, request, render_template
from flask_cors import CORS
from flask_datepicker import datepicker
import methods


app = Flask(__name__)
CORS(app)
datepicker(app)


@app.route('/', methods=['GET', 'POST'])
def index():
    if 'GET' == request.method:
        if request.args:
            prediction_object = methods.predict(request.args['country'], request.args['futuredate'])
            return render_template('index.html',
                                   sel_country=request.args['country'],
                                   today_date=prediction_object['today_date'],
                                   today_cases=prediction_object['today_cases'],
                                   predict_date=prediction_object['predict_date'],
                                   predict_cases=prediction_object['predict_cases'])
        else:
            return render_template('index_static.html')
    else:
        return render_template('index_static.html')


if __name__ == '__main__':
    app.run()
